# Resource report
This packaging operation uses zero model calls. Saved recovery experiment:
18 calls / 14,878 tokens. Saved manuscript writing: 3 calls / 24,015 tokens.
These two selected stages total 21 calls / 38,893 tokens; local editorial changes
add zero model calls. CPU replays and post-hoc normalization are not extra model calls.

All historical campaigns total 42 calls / 123,863 tokens:
15 calls / 52,438 tokens (historical smoke, topic, arithmetic pilot, old paper)
+ 24 calls / 47,410 tokens (research-v2, including recovery experiment)
+ 3 calls / 24,015 tokens (recovery manuscript writing).
These are cumulative project totals, not the cost of one final submission run.
The older historical-resource-audit.json covers only the first 15 calls.
Raw writing usage and continuation provenance are saved in code/BDCI/research/
replay_paper_runs; recovery usage is saved in replay_runs. Scientific results are
from six self-authored base instances and are not independent held-out validation.
Actual monetary cost is unknown. The selected study wall time is not full research,
editorial, compilation or end-to-end project duration. No GPU training was performed.
