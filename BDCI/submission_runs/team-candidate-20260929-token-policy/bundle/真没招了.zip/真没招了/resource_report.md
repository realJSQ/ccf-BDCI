# Resource report

This packaging operation uses zero model calls.
Selected recovery experiment: 18 calls / 14,878 tokens.
Selected manuscript writing: 3 calls / 24,015 tokens.
These stages total 21 calls /
38,893 tokens. Local editorial changes,
CPU replays and post-hoc normalization add zero model calls.

The explicit archived live-run inventory totals 47 calls /
192,805 tokens, including failed and truncated follow-up design
requests. This is cumulative development usage, not one final submission run.
See resource_audit.json and code/BDCI/research/resource_runs.json for per-run
usage, source hashes and recorded stage durations. Raw usage and summaries are
included in code/BDCI and recomputed by the unpacked bundle verifier.

This inventory excludes offline fixtures, Codex development assistance, retrieval
and external review. Future runs require updating the explicit inventory.
Actual monetary cost and end-to-end wall time remain unknown; recorded stage
durations have different boundaries and are not summed. API usage is not a bill.
The six self-authored study instances are not independent held-out validation.
No GPU training was performed.
