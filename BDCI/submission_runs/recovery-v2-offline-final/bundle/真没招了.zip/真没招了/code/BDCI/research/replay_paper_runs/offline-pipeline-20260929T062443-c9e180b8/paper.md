# Static dependency recovery: integration fixture

**Self-authored structural holdout study**

Anonymous authors.

## Abstract

This scripted manuscript validates the evidence-to-PDF pipeline and is not a new scientific result.

## Introduction

This developer-scripted section tests the manuscript pipeline. The saved study concerns self-authored structural held-out workflows with shared static tool contracts. The deterministic baseline requires no model plan. Replays and scenarios are repeated measures. Developer intervention in protocol revision is recorded; no autonomous discovery or generalization is claimed.

## Related Work

This developer-scripted section tests the manuscript pipeline. The saved study concerns self-authored structural held-out workflows with shared static tool contracts. The deterministic baseline requires no model plan. Replays and scenarios are repeated measures. Developer intervention in protocol revision is recorded; no autonomous discovery or generalization is claimed.

References: ref0001,ref0002,ref0003

## Methods

This developer-scripted section tests the manuscript pipeline. The saved study concerns self-authored structural held-out workflows with shared static tool contracts. The deterministic baseline requires no model plan. Replays and scenarios are repeated measures. Developer intervention in protocol revision is recorded; no autonomous discovery or generalization is claimed.

## Results

Rendering mode: offline_scripted. A: Model-requested reruns in their original order, including duplicates. D: Model requests union declared-graph closure of changed sources; actual topological order. E: Model requests union actual-graph closure of changed sources; actual topological order. F: Full replay when sources change; deduplicated model requests on clean inputs. G: Deterministic actual-graph closure of changed sources; no model plan required.

### Scenario-by-policy results

| Scenario | Policy | n | Correct | Wrong | Noncompl. | Calls | Stale |
|---|---|---|---|---|---|---|---|
| clean | A | 9 | 9 | 0 | 0 | 0 | 0 |
| clean | D | 9 | 9 | 0 | 0 | 0 | 0 |
| clean | E | 9 | 9 | 0 | 0 | 0 | 0 |
| clean | F | 9 | 9 | 0 | 0 | 0 | 0 |
| clean | G | 9 | 9 | 0 | 0 | 0 | 0 |
| aux update | A | 9 | 9 | 0 | 0 | 78 | 0 |
| aux update | D | 9 | 9 | 0 | 0 | 78 | 0 |
| aux update | E | 9 | 9 | 0 | 0 | 78 | 0 |
| aux update | F | 9 | 9 | 0 | 0 | 138 | 0 |
| aux update | G | 9 | 9 | 0 | 0 | 78 | 0 |
| joint update | A | 9 | 9 | 0 | 0 | 138 | 0 |
| joint update | D | 9 | 9 | 0 | 0 | 138 | 0 |
| joint update | E | 9 | 9 | 0 | 0 | 138 | 0 |
| joint update | F | 9 | 9 | 0 | 0 | 138 | 0 |
| joint update | G | 9 | 9 | 0 | 0 | 138 | 0 |
| incomplete lineage | A | 9 | 9 | 0 | 0 | 78 | 0 |
| incomplete lineage | D | 9 | 9 | 0 | 0 | 78 | 0 |
| incomplete lineage | E | 9 | 9 | 0 | 0 | 78 | 0 |
| incomplete lineage | F | 9 | 9 | 0 | 0 | 138 | 0 |
| incomplete lineage | G | 9 | 9 | 0 | 0 | 78 | 0 |

### Paired base-instance results

| Case | A | D | E | F | G | E-A correct | E-A calls |
|---|---|---|---|---|---|---|---|
| 1 | 4/4; 30 | 4/4; 30 | 4/4; 30 | 4/4; 42 | 4/4; 30 | 0 | 0 |
| 2 | 4/4; 32 | 4/4; 32 | 4/4; 32 | 4/4; 48 | 4/4; 32 | 0 | 0 |
| 3 | 4/4; 36 | 4/4; 36 | 4/4; 36 | 4/4; 48 | 4/4; 36 | 0 | 0 |
| 4 | 4/4; 30 | 4/4; 30 | 4/4; 30 | 4/4; 42 | 4/4; 30 | 0 | 0 |
| 5 | 4/4; 32 | 4/4; 32 | 4/4; 32 | 4/4; 48 | 4/4; 32 | 0 | 0 |
| 6 | 4/4; 36 | 4/4; 36 | 4/4; 36 | 4/4; 48 | 4/4; 36 | 0 | 0 |
| 7 | 4/4; 30 | 4/4; 30 | 4/4; 30 | 4/4; 42 | 4/4; 30 | 0 | 0 |
| 8 | 4/4; 32 | 4/4; 32 | 4/4; 32 | 4/4; 48 | 4/4; 32 | 0 | 0 |
| 9 | 4/4; 36 | 4/4; 36 | 4/4; 36 | 4/4; 48 | 4/4; 36 | 0 | 0 |

Each policy cell is correct/episodes; calls, aggregated over the four scenarios. Differences are paired raw counts, not significance tests.

Case mapping: 1: recovery-v2-heldout-tabular-m2-a2-11009; 2: recovery-v2-heldout-tabular-m3-a2-11026; 3: recovery-v2-heldout-tabular-m2-a3-11043; 4: recovery-v2-heldout-retrieval-m2-a2-11110; 5: recovery-v2-heldout-retrieval-m3-a2-11127; 6: recovery-v2-heldout-retrieval-m2-a3-11144; 7: recovery-v2-heldout-classification-m2-a2-11211; 8: recovery-v2-heldout-classification-m3-a2-11228; 9: recovery-v2-heldout-classification-m2-a3-11245.

36 saved model plans are shared by A/D/E/F, yielding 144 model-policy replays. G requires zero model calls and has 36 separate deterministic executions. The 180 executions are not independent samples; 9 base instances are the paired units. Calls exclude shared initial-cache construction. Noncompletion includes malformed plans and does not imply voluntary refusal. Stale counts completed outputs with outdated source provenance, separately from numerical correctness.

Actual tool dependencies and declared dependencies are visible to the planner and every policy. Actual dependencies are supplied tool contracts, not discovered dependencies.

The research question follows Agent proposals; the developer corrected dependency propagation, oracle definition, matched information, and structural split before this frozen experiment. Development fixtures are CPU checks, not model observations.

Study scope and limitations: Nine self-authored base instances are the paired analysis units; scenarios and policy replays are repeated measures. One saved model plan per episode is reused for A/D/E/F; G is deterministic and does not consume that plan. This is a small self-authored structural holdout, not independent external validation or a public benchmark. The local pre-run freeze is not public preregistration; the protocol was developer assisted. The reference scorer is a separate implementation by the same authors, not external independent reproduction. Numerical correctness and source freshness are separate outcomes; malformed plans are not voluntary refusal. Static actual-graph closure is an existing mechanism; no novel dependency-discovery algorithm is established. Comparisons include E versus A and G as well as F; equality does not establish statistical equivalence or generalization. Tool-call counts exclude shared initial-cache construction and are not measured monetary or computational cost. No transient failures were injected; no retry-effectiveness claim is supported.

Recorded study resources: model calls: 36; total tokens: 113384; duration seconds: 47.758; initial cache tool calls: 138; cost: unavailable; Native study invocation only; excludes development, literature, and writing.

## Discussion

This developer-scripted section tests the manuscript pipeline. The saved study concerns self-authored structural held-out workflows with shared static tool contracts. The deterministic baseline requires no model plan. Replays and scenarios are repeated measures. Developer intervention in protocol revision is recorded; no autonomous discovery or generalization is claimed.

## Conclusion

This developer-scripted section tests the manuscript pipeline. The saved study concerns self-authored structural held-out workflows with shared static tool contracts. The deterministic baseline requires no model plan. Replays and scenarios are repeated measures. Developer intervention in protocol revision is recorded; no autonomous discovery or generalization is claimed.

## References

- [ref0001] AgentCheck: A Reproduce-Intervene-Mitigate Workbench for LLM Agents over MCP. Aritra Mazumder; Nusrat jahan Lia. 2026. https://arxiv.org/abs/2607.11098v1

- [ref0002] Correct Is Not Governed: Provenance Integrity in Agentic Workflows. Jesus Salas. 2026. https://arxiv.org/abs/2608.12761v1

- [ref0003] Evaluating Tool-Using Language Agents: Judge Reliability, Propagation Cascades, and Runtime Mitigation in AgentProp-Bench. Bhaskar Gurram. 2026. https://arxiv.org/abs/2604.16706v1
