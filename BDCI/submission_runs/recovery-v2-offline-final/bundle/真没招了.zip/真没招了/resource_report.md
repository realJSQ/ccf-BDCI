# Resource report

This packaging operation uses zero model calls.
Selected recovery experiment: 36 calls / 113,384 tokens.
Scripted integration fixture (not live API): 3 calls / 6 tokens.
These stages total 36 live API calls /
113,384 live API tokens. Local editorial changes,
CPU replays and post-hoc normalization add zero model calls.

The explicit archived live-run inventory totals 83 calls /
306,189 tokens, including failed and truncated follow-up design
requests. This is cumulative development usage, not one final submission run.
See resource_audit.json and code/BDCI/research/resource_runs.json for per-run
usage, source hashes and recorded stage durations. Raw usage and summaries are
included in code/BDCI and recomputed by the unpacked bundle verifier.

This inventory excludes offline fixtures, Codex development assistance, retrieval
and external review. Future runs require updating the explicit inventory.
Actual monetary cost and end-to-end wall time remain unknown; recorded stage
durations have different boundaries and are not summed. API usage is not a bill.
The nine self-authored structurally held-out base instances are not independent external validation.
No GPU training was performed.
