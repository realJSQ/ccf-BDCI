# Saved recovery evidence
Saved-evidence verification needs only Python 3.13 standard library, without
credentials, framework installation or model calls. From this code directory:
```bash
python -S BDCI/research/build_replay_bundle.py --verify ..
python BDCI/research/recovery_v2_runs/live-20260929T060132-126279/frozen_source/research/run_recovery_v2.py --verify-run BDCI/research/recovery_v2_runs/live-20260929T060132-126279
```
These commands use saved responses and CPU replay, without model APIs or credentials.
The first verifies file hashes, raw-response equality, review bindings, editorial
provenance, PDF hash, writing accounting and the selected study replay evidence.
It does not certify scientific novelty or external review. Dependency installation
and framework setup are documented in README.md. TeX recompilation requires the
lightweight Tectonic installation and its font/package cache; neither is bundled.
Original absolute paths in provenance are historical metadata; verification resolves
selected run names relative to this archive. No live run is needed for verification.
