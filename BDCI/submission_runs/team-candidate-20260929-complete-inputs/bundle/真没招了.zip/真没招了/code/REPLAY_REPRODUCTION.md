# Saved recovery evidence
From this code directory, using Python 3.13 and the installed project dependencies:
```bash
python BDCI/research/build_replay_bundle.py --verify ..
python BDCI/research/analyze_replay.py BDCI/research/replay_runs/live-20260928T144804-532140 --verify-only
```
These commands use saved responses and CPU replay, without model APIs or credentials.
The first verifies file hashes, raw-response equality, review bindings, editorial
provenance, PDF hash, writing accounting and strict/post-hoc replay evidence.
It does not certify scientific novelty or external review. Dependency installation
and framework setup are documented in README.md. TeX recompilation requires the
lightweight Tectonic installation and its font/package cache; neither is bundled.
Original absolute paths in provenance are historical metadata; verification resolves
selected run names relative to this archive. No live run is needed for verification.
