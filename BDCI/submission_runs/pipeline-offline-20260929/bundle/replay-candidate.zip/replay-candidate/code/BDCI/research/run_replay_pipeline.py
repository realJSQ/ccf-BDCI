"""Coordinate verified study -> native manuscript -> candidate -> unpacked verification.

This is the post-study portion of research automation, not autonomous topic or
experiment generation. Offline manuscripts are integration fixtures. No new
budget is created, and uncertain model requests are never automatically resent.
"""
import argparse
from datetime import datetime, timezone
import fcntl
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import uuid
import zipfile

sys.dont_write_bytecode = True

import build_replay_bundle as bundle
from replay_paper_evidence import build_evidence, digest

HERE = Path(__file__).resolve().parent


def save(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + '\n')
    temporary.replace(path)


def call_writer(paper, study, output, *, live, recover):
    command = [sys.executable, str(HERE / 'run_replay_paper.py'),
               '--study-run', str(study), '--no-latest']
    command += ['--resume' if recover else '--output-run', str(paper)]
    if live and not recover:
        command.append('--live')
    attempt = uuid.uuid4().hex[:12]
    with (output / f'writer-{attempt}.stdout').open('w') as stdout, (
            output / f'writer-{attempt}.stderr').open('w') as stderr:
        result = subprocess.run(command, cwd=HERE.parent.parent, stdout=stdout, stderr=stderr)
    if result.returncode:
        raise RuntimeError('native_writing_failed_inspect_saved_run')


def manuscript_fingerprint(paper, study):
    bundle.validate_manuscript(paper, study)
    bundle.validate_rendered_sources(paper)
    chain = bundle.writing_chain(paper)
    return {str(Path(run.name) / name): bundle.sha(run / name)
            for run in chain for name in bundle.PAPER_FILES if (run / name).is_file()}


def verify_archive(archive):
    """Run the delivered verifier, not merely the development-tree version."""
    with tempfile.TemporaryDirectory(prefix='replay-pipeline-verify-') as temporary:
        with zipfile.ZipFile(archive) as zipped:
            for name in zipped.namelist():
                path = Path(name)
                if path.is_absolute() or '..' in path.parts or path.parts[0] != 'replay-candidate':
                    raise ValueError('unsafe_candidate_archive')
            zipped.extractall(temporary)
        stage = Path(temporary) / 'replay-candidate'
        command = [sys.executable, str(stage / 'code/BDCI/research/build_replay_bundle.py'),
                   '--verify', str(stage)]
        result = subprocess.run(command, cwd=stage / 'code', capture_output=True, text=True, timeout=120)
        if result.returncode:
            raise ValueError('unpacked_candidate_verification_failed')
        return json.loads(result.stdout)


def run_pipeline(study, output, *, paper=None, live=False, resume=False):
    study, output = Path(study).resolve(), Path(output).resolve()
    if resume:
        if not (output / 'pipeline.json').is_file():
            raise ValueError('missing_pipeline_state')
    else:
        output.mkdir(parents=True, exist_ok=False)
    with (output / 'pipeline.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        state_path = output / 'pipeline.json'
        if resume:
            state = bundle.read(state_path)
            if state.get('schema_version') != 1:
                raise ValueError('unsupported_pipeline_state')
            if live:
                raise ValueError('resume_uses_saved_mode')
            if paper is not None and Path(paper).resolve() != Path(state['paper_run']):
                raise ValueError('pipeline_paper_input_changed')
        else:
            identifier = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S-') + uuid.uuid4().hex[:8]
            state = {'schema_version': 1, 'status': 'running', 'stages': {},
                'study_run': str(study), 'paper_origin': 'saved' if paper else 'native',
                'paper_run': str(Path(paper).resolve()) if paper else str(
                    HERE / 'replay_paper_runs' / (('live' if live else 'offline') + '-pipeline-' + identifier)),
                'writing_live': live, 'submission_ready': False,
                'scope': 'Completed compatible study through candidate packaging; topic and experiment stages are separate.'}
            save(state_path, state)
        stages = state['stages']
        current = 'evidence'
        started = time.monotonic()
        try:
            evidence = build_evidence(study)
            signature = digest(evidence)
            if 'evidence_sha256' in state and signature != state['evidence_sha256']:
                raise ValueError('pipeline_study_input_changed')
            state.update(study_run=str(study), evidence_sha256=signature, status='running')
            stages['evidence'] = {'status': 'verified', 'evidence_sha256': signature}
            save(state_path, state)
            current = 'manuscript'
            paper = Path(state['paper_run'])
            previous = stages.get(current, {})
            if previous.get('status') == 'completed':
                if manuscript_fingerprint(paper, study) != previous['files']:
                    raise ValueError('pipeline_manuscript_changed')
            else:
                if state['paper_origin'] == 'native':
                    # A recorded attempt or existing directory may contain an API
                    # request whose outcome is unknown. Only replay complete raws.
                    recover = bool(previous) or paper.exists()
                    if recover and not all((paper / name).is_file() for name in (
                            'model_summary.json', 'raw_writer.txt', 'raw_reviewer.txt', 'raw_reviser.txt')):
                        raise ValueError('incomplete_writing_requires_explicit_recovery_no_automatic_retry')
                    stages[current] = {'status': 'running', 'paper_run': str(paper),
                                       'recovery_without_api': recover}
                    save(state_path, state)
                    call_writer(paper, study, output, live=state['writing_live'], recover=recover)
                files = manuscript_fingerprint(paper, study)
                stages[current] = {'status': 'completed', 'files': files}
                save(state_path, state)
            current = 'bundle'
            archive = output / 'bundle/replay-candidate.zip'
            previous = stages.get(current, {})
            if previous.get('status') == 'completed':
                if not archive.is_file() or bundle.sha(archive) != previous['zip_sha256']:
                    raise ValueError('pipeline_archive_changed')
            elif archive.exists():
                # A complete archive may survive a crash before checkpointing.
                # Verify its manuscript binding before adopting, never overwrite.
                verify_archive(archive)
                with zipfile.ZipFile(archive) as zipped:
                    manifest = json.loads(zipped.read('replay-candidate/manifest.json'))
                if (manifest['paper_run'] != paper.name
                        or manifest['paper_sha256'] != bundle.sha(paper / 'paper.pdf')):
                    raise ValueError('pipeline_archive_target_mismatch')
                stages[current] = {'status': 'completed', 'zip_sha256': bundle.sha(archive)}
                save(state_path, state)
            else:
                stages[current] = {'status': 'running'}
                save(state_path, state)
                built = bundle.build_bundle(paper, output / 'bundle', study_run=study)
                if built != archive:
                    raise ValueError('unexpected_pipeline_archive')
                stages[current] = {'status': 'completed', 'zip_sha256': bundle.sha(archive)}
                save(state_path, state)
            current = 'unpacked_verification'
            checked = verify_archive(archive)
            stages[current] = {'status': 'verified', 'result': checked}
            mode = bundle.read(paper / 'summary.json')['mode']
            state.update(status='saved_candidate_verified' if mode == 'live' else 'integration_candidate_verified',
                         writing_mode=mode, submission_ready=False,
                         last_invocation_duration_seconds=time.monotonic() - started)
            state.pop('last_error', None)
            save(state_path, state)
            return state
        except BaseException as error:
            state.update(status='failed', last_error={'stage': current, 'error_type': type(error).__name__,
                         'message': str(error) if isinstance(error, ValueError) else 'See saved stage artifacts'},
                         last_invocation_duration_seconds=time.monotonic() - started)
            save(state_path, state)
            raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-run', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--paper-run', type=Path, help='Reuse saved manuscript; otherwise invoke native writing')
    parser.add_argument('--live', action='store_true', help='Use existing writing budget; never resets it')
    parser.add_argument('--resume', action='store_true', help='Verify checkpoints and recover without reissuing model requests')
    args = parser.parse_args()
    try:
        state = run_pipeline(args.study_run, args.output, paper=args.paper_run,
                             live=args.live, resume=args.resume)
        print(json.dumps({'status': state['status'], 'output': str(args.output.resolve()),
                          'paper_run': state['paper_run'], 'submission_ready': False}))
        return 0
    except Exception as error:
        print(json.dumps({'status': 'failed', 'error_type': type(error).__name__,
                          'output': str(args.output.resolve())}))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
