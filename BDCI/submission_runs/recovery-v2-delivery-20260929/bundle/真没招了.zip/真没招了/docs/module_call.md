# 所选 v2 模块调用与复现

以下命令从 ZIP 的 `code` 目录执行。依赖安装见该目录 README.md；保存证据验证不需要 API 密钥。

```bash
python BDCI/research/build_replay_bundle.py --verify ..
python BDCI/research/recovery_v2_runs/live-20260929T060132-126279/frozen_source/research/run_recovery_v2.py --verify-run BDCI/research/recovery_v2_runs/live-20260929T060132-126279
```

第一条验证本包文件清单、原始写作响应、审稿目标与引文、研究和角色配置绑定、
确定性渲染来源、PDF哈希、资源清单及冻结研究重放。第二条独立复算36份计划和180次策略执行。
冻结 verifier 需要保留研究目录 basename。它们不会重发模型请求；PDF哈希一致不等于论文语义正确。

真实研究：`run_recovery_v2.py` → 公共工具契约与旧缓存 → 顺序模型计划 →
`recovery_v2_engine.py` 五策略CPU执行 → 独立实现的同作者评分器 → 冻结存档。
写作：`run_replay_paper.py --study-kind recovery_v2 --study-run <run>` →
`recovery_v2_paper_evidence.build_evidence` → recovery-v2-paper team skill 的三角色 →
`recovery_v2_paper_render` → Tectonic。当前 v2 没有1600词或人为token上限。
内部 reviewer 使用同一模型服务，不是 Stanford 外审。

可在依赖和轻量LaTeX就绪后，用已有研究运行新的离线编排验证：
```bash
python BDCI/research/run_replay_pipeline.py --study-kind recovery_v2 --study-run BDCI/research/recovery_v2_runs/live-20260929T060132-126279 --output /tmp/recovery-v2-new-integration --team-name 真没招了
```

输出目录必须新建；不带 --live 的写作是脚本响应，不新增真实科学实验。
本包实际写作模式为 `live`；不要运行 --live 来复现保存结果。
实验后协调器保存研究哈希、论文链和ZIP检查点，部分模型响应缺失时不自动重复请求。
选题、提案、协议冻结、外审、正式提交仍不在这一协调入口内。
