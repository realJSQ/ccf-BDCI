# 当前作品架构：recovery_v2

本说明绑定本包研究 `recovery_v2_runs/live-20260929T060132-126279`、论文 `editorial-recovery-v2-20260929`，写作模式 `live`。
本包尚不可正式提交。仓库历史说明保留在 code/BDCI/docs/submission，
其中旧六实例、18计划、72次重放及严格/事后终止修复属于 v1 历史研究，不能当作本轮结果。

Agent 的选题、方法提案与协议审查使用 JiuwenSwarm 原生 team skill；
开发助手纠正依赖传播、评分真值、信息对称和数据划分后，冻结本轮方案。
选题到实验仍是多个入口，外审与正式提交尚未接入自动闭环。

当前实验由 [run_recovery_v2.py](../code/BDCI/research/run_recovery_v2.py) 顺序取得36份模型计划，
在本地CPU执行 A/D/E/F 四个共用计划的策略及不依赖模型计划的确定性 G 策略，合计180次。
九个自编结构留出基础实例各含四种场景；不是180个独立样本，也不是外部独立验证。
冻结输入、源码、原始响应及结果在 [研究目录](../code/BDCI/research/recovery_v2_runs/live-20260929T060132-126279/)。

实验后 [run_replay_pipeline.py](../code/BDCI/research/run_replay_pipeline.py) 协调
冻结证据复验 → 原生 writer/reviewer/reviser → LaTeX/PDF → 候选ZIP → 包内校验。
[study_adapter.py](../code/BDCI/research/study_adapter.py) 按显式 study_kind 选择证据、角色和渲染器；
`recovery_v2_evidence/1` 与旧证据结构分别处理，失败不会回退另一研究。
模型文本与数值表分离；数值表来自复验结果。结构检查、哈希和内部审稿不认证科学结论。

[native_runner.py](../code/BDCI/research/native_runner.py) 通过 SwarmFlow、TeamWorkerBackend、DeepAgent
调用模型，注册 ResearchBudgetRail 及官方 skill-use Rail；研究角色 tools=[]，
本地重放和证据检查由 Python 控制程序执行。ExperimentEvidenceRail 仅接入独立 smoke 工具路径。
当前 v2 调用不设人为 token 停止阈值，保留服务自身容量、请求计数、usage与未完成准入保护。
离线写作使用脚本模型，仅验证控制流程；不能宣称新论文由真实模型生成。
