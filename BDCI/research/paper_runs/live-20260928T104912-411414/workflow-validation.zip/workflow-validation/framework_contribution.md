# Framework contribution status
Two local source modules are supplied in code/framework_overlay:
research_budget_rail.py and research_evidence_rail.py. They are registered by
the research runners. No upstream PR has been submitted or accepted; no PR URL
is supplied. Competition contribution requirements remain incomplete.
