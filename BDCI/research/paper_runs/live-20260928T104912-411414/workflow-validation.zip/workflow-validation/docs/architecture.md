# Architecture
JiuwenSwarm native SwarmFlow and TeamWorkerBackend run research skills.
Local contracts validate references and plans; deterministic code scores saved
pilot answers and renders evidence tables. Writing, internal review and revision
use separate roles. Source Rails enforce model admissions and evidence integrity.
