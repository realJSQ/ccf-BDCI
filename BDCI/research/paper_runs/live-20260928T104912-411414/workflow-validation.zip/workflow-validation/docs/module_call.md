# Module calls
Topic search → proposal → critique → revised plan → pilot review → saved paired
pilot → deterministic scoring → writer → internal reviewer → reviser → ICLR
LaTeX renderer → PDF → this dry-run bundle. Packaging reuses the saved pilot;
it neither reruns experiments nor calls a model.
