# Reproduction
Official base: https://atomgit.com/openJiuwen/jiuwenswarm
Pinned commit: `fc18e5c572a6b3b62bb42ea843cce674140e4266`. The official base is not duplicated in this archive.

From this `code` directory, obtain the base and overlay the two source Rails:
```bash
git clone https://atomgit.com/openJiuwen/jiuwenswarm BDCI/jiuwenswarm
git -C BDCI/jiuwenswarm checkout fc18e5c572a6b3b62bb42ea843cce674140e4266
cp -R framework_overlay/jiuwenswarm/. BDCI/jiuwenswarm/jiuwenswarm/
python3.13 -m venv BDCI/.venv
BDCI/.venv/bin/python -m pip install -r BDCI/setup/requirements.repro.txt
BDCI/.venv/bin/python -m pip install --no-deps -e BDCI/jiuwenswarm
source BDCI/activate.sh
```
No Git global configuration is required. Dependency installation and lightweight
TeX setup require network access; no installer was run by this packaging step.
Use `bash BDCI/setup/latex-install.sh`, then compile the delivered source with
`BDCI/tools/compile-latex.sh --outdir ../paper ../paper/paper.tex`.
The archive contains saved source, paper, internal review and pilot evidence.
Offline script modes are simulations; they do not establish a research result.
Do not run `--live` to reproduce the saved paper: live modes spend new API calls.
Credentials are intentionally absent. Restore paths or pass an explicit saved
pilot path if a runner default points to a differently named local run.
